package com.pecit.lms.Controller;

import com.pecit.lms.dto.UpdateBookDto;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.*;

import com.pecit.lms.Service.BookService;
import com.pecit.lms.dto.BookRequestDto;
import com.pecit.lms.dto.BookResponseDto;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("v1/books")
public class BookController {
    @Autowired
    private BookService bookService;
    private final Logger logger = LoggerFactory.getLogger(BookController.class);

    @PostMapping
    public ResponseEntity<BookResponseDto> createBook(@Valid @RequestBody BookRequestDto bookRequest) {
        logger.info("Details provided for the Book : {}", bookRequest.getName());
        BookResponseDto bookResponse = bookService.createBook(bookRequest);
        return new ResponseEntity<>(bookResponse, HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<BookResponseDto>> fetchAllBooks() {
        List<BookResponseDto> bookResponses = bookService.fetchAllBooks();
        return new ResponseEntity<>(bookResponses, HttpStatus.OK);
    }

    @GetMapping("{bookId}")
    public ResponseEntity<?> fetchBookById(@PathVariable UUID bookId) {
        logger.info("Fetching the Book with Id : {}", bookId);
        BookResponseDto bookResponse = bookService.fetchBookById(bookId);
        if (ObjectUtils.isEmpty(bookResponse)) {
            return new ResponseEntity<>("Book does not exist on Id : " + bookId, HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(bookResponse, HttpStatus.OK);
    }

    @DeleteMapping("{bookId}")
    public ResponseEntity<?> deleteBookById(@PathVariable UUID bookId) {
        logger.info("Details provided for the Deleting the Book : {}", bookId);
        Boolean isDeleted = bookService.deleteBookById(bookId);
        if (isDeleted) {
            return new ResponseEntity<>("Book with Id : " + bookId + " deleted successfully", HttpStatus.NO_CONTENT);
        }
        return new ResponseEntity<>("Book does not exist for id : " + bookId, HttpStatus.NOT_FOUND);
    }

    @PutMapping("{bookId}")
    public ResponseEntity<?> updateBook(@PathVariable UUID bookId, @Valid @RequestBody UpdateBookDto updateBook) {
        logger.info("Details provided for  updating the Book : {}", bookId);
        BookResponseDto bookResponse = bookService.updateBook(bookId, updateBook);
        if (ObjectUtils.isEmpty(bookResponse)) {
            return new ResponseEntity<>("Book does not exist for id : " + bookId, HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(bookResponse, HttpStatus.OK);
    }
}