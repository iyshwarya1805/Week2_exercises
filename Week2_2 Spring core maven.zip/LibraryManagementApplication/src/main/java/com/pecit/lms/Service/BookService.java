package com.pecit.lms.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import com.pecit.lms.dto.UpdateBookDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pecit.lms.Model.Book;
import com.pecit.lms.Repository.BookRepository;
import com.pecit.lms.dto.BookRequestDto;
import com.pecit.lms.dto.BookResponseDto;

@Service
public class BookService {
    @Autowired
    private BookRepository bookRepository;

    public BookResponseDto createBook(BookRequestDto bookRequest) {
        try {
            Book book = Book.builder()
                    .name(bookRequest.getName())
                    .authorName(bookRequest.getAuthorName())
                    .category(bookRequest.getCategory())
                    .prize(bookRequest.getPrize()).build();
            bookRepository.save(book);
            return BookResponseDto.builder()
                    .id(book.getId())
                    .name(book.getName())
                    .authorName(book.getAuthorName())
                    .prize(book.getPrize())
                    .category(book.getCategory()).build();
        } catch (Exception e) {
            throw new RuntimeException("Occurred while storing book with name : " + bookRequest.getName(), e);
        }
    }

    public List<BookResponseDto> fetchAllBooks() {
        try {
            List<Book> books = bookRepository.findAll();
            List<BookResponseDto> bookResponses = new ArrayList<>();
            for (Book book : books) {
                bookResponses.add(BookResponseDto.builder()
                        .id(book.getId())
                        .name(book.getName())
                        .authorName(book.getAuthorName())
                        .prize(book.getPrize())
                        .category(book.getCategory()).build());
            }
            return bookResponses;
        } catch (Exception e) {
            throw new RuntimeException("Occurred while retrieving all the books", e);
        }
    }

    public BookResponseDto fetchBookById(UUID bookId) {
        try {
            Optional<Book> existingBook = bookRepository.findById(bookId);
            if (existingBook.isPresent()) {
                Book book = existingBook.get();
                return BookResponseDto.builder()
                        .id(book.getId())
                        .name(book.getName())
                        .authorName(book.getAuthorName())
                        .prize(book.getPrize())
                        .category(book.getCategory()).build();
            }
            return null;
        } catch (Exception e) {
            throw new RuntimeException("Occurred while fetching book with id : " + bookId, e);
        }
    }

    public Boolean deleteBookById(UUID bookId) {
        try {
            Optional<Book> existingBook = bookRepository.findById(bookId);
            if (existingBook.isPresent()) {
                Book book = existingBook.get();
                bookRepository.delete(book);
                return true;
            }
            return false;
        } catch (Exception e) {
            throw new RuntimeException("Occurred while deleting book with id : " + bookId, e);
        }
    }

    public BookResponseDto updateBook(UUID bookId, UpdateBookDto updateBook) {
        try {
            Optional<Book> existingBook = bookRepository.findById(bookId);
            if (existingBook.isPresent()) {
                Book book = Book.builder()
                        .id(bookId)
                        .name(updateBook.getName())
                        .authorName(updateBook.getAuthorName())
                        .category(updateBook.getCategory())
                        .prize(updateBook.getPrize()).build();
                bookRepository.save(book);
                return BookResponseDto.builder()
                        .id(book.getId())
                        .name(book.getName())
                        .authorName(book.getAuthorName())
                        .prize(book.getPrize())
                        .category(book.getCategory()).build();
            }
            return null;
        } catch (Exception e) {
            throw new RuntimeException("Occurred while updating book with id : " + bookId, e);
        }
    }
}