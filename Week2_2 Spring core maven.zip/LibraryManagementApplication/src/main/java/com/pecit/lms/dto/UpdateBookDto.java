package com.pecit.lms.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Builder
@Getter
@Setter
public class UpdateBookDto {
    @NotBlank(message = "Book name should not be blank")
    @Pattern(regexp = "^[a-zA-Z\\s]+$", message = "Book name accepts only a-z A-Z")
    private String name;

    @NotBlank(message = "Author name should not be blank")
    @Pattern(regexp = "^[a-zA-Z\\s]+$", message = "Author name accepts only a-z A-Z")
    private String authorName;

    @NotNull(message = "Prize should not be blank")
    private double prize;

    @NotBlank(message = "Category name should not be blank")
    @Pattern(regexp = "^[a-zA-Z\\s]+$", message = "Category name accepts only a-z A-Z")
    private String category;
}
