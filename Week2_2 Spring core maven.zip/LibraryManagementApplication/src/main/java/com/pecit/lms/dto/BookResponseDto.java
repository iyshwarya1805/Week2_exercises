package com.pecit.lms.dto;

import java.util.UUID;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Builder
@Getter@Setter
public class BookResponseDto {
    private UUID id;
    private String name;
    private String authorName;
    private double prize;
    private String category;
}